"use client";

import { useMemo, useState } from "react";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import {
  Rocket,
  Check,
  Loader2,
  AlertCircle,
  Globe,
  ExternalLink,
  Circle,
} from "lucide-react";
import { useEditor } from "@/lib/editor/store";
import { useDomains } from "@/hooks/use-domains";
import { CLUSTER } from "@/lib/solana";
import { serializeSiteToHtml } from "@/lib/publish/serialize";
import {
  publishSite,
  type PublishMode,
  type PublishResult,
  type StepId,
  type StepStatus,
} from "@/lib/publish/publish";
import type { WalletSigner } from "@/lib/iqlabs";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ConnectButton } from "@/components/wallet/connect-button";
import { cn, shortKey } from "@/lib/utils";

const STEPS: { id: StepId; label: string }[] = [
  { id: "serialize", label: "Serialize site → HTML" },
  { id: "inscribe", label: "Inscribe on Solana (IQLabs)" },
  { id: "record", label: "Point .sol domain at it (SNS)" },
];

function explorerTx(sig: string) {
  const c = CLUSTER === "mainnet-beta" ? "" : `?cluster=${CLUSTER}`;
  return `https://explorer.solana.com/tx/${sig}${c}`;
}

function StepRow({
  label,
  status,
  detail,
}: {
  label: string;
  status: StepStatus;
  detail?: string;
}) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <span className="flex size-5 items-center justify-center">
        {status === "done" ? (
          <Check size={16} className="text-primary" />
        ) : status === "active" ? (
          <Loader2 size={16} className="animate-spin text-primary" />
        ) : status === "error" ? (
          <AlertCircle size={16} className="text-destructive" />
        ) : (
          <Circle size={10} className="text-muted-foreground" />
        )}
      </span>
      <span
        className={cn(
          "text-sm",
          status === "pending" ? "text-muted-foreground" : "text-foreground",
        )}
      >
        {label}
      </span>
      {detail && (
        <span className="ml-auto max-w-[160px] truncate font-mono text-[11px] text-muted-foreground">
          {detail}
        </span>
      )}
    </div>
  );
}

export function PublishDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { connection } = useConnection();
  const { publicKey, signTransaction, signAllTransactions, connected } = useWallet();
  const { state } = useEditor();
  const { domains, loading, error } = useDomains();

  const [selected, setSelected] = useState<string | null>(null);
  const [mode, setMode] = useState<PublishMode>("simulate");
  const [running, setRunning] = useState(false);
  const [steps, setSteps] = useState<Record<StepId, StepStatus>>({
    serialize: "pending",
    inscribe: "pending",
    record: "pending",
    done: "pending",
  });
  const [details, setDetails] = useState<Record<string, string>>({});
  const [result, setResult] = useState<PublishResult | null>(null);
  const [failure, setFailure] = useState<string | null>(null);

  const html = useMemo(() => serializeSiteToHtml(state.site), [state.site]);

  const walletSigner: WalletSigner | null =
    publicKey && signTransaction && signAllTransactions
      ? { publicKey, signTransaction, signAllTransactions }
      : null;

  const canPublish =
    !!walletSigner && !!selected && state.site.blocks.length > 0 && !running;

  async function handlePublish() {
    if (!walletSigner || !selected) return;
    setRunning(true);
    setResult(null);
    setFailure(null);
    setSteps({ serialize: "pending", inscribe: "pending", record: "pending", done: "pending" });
    setDetails({});
    try {
      const res = await publishSite({
        connection,
        wallet: walletSigner,
        site: state.site,
        domain: selected,
        mode,
        onStep: ({ step, status, detail }) => {
          setSteps((s) => ({ ...s, [step]: status }));
          if (detail) setDetails((d) => ({ ...d, [step]: detail }));
        },
      });
      setResult(res);
    } catch (e) {
      setFailure((e as Error).message ?? "Publish failed");
    } finally {
      setRunning(false);
    }
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full p-0 sm:max-w-xl">
        <ScrollArea className="h-full">
          <div className="p-6">
            <SheetHeader>
              <SheetTitle className="flex items-center gap-2 font-display">
                <Rocket size={18} className="text-primary" /> Publish on-chain
              </SheetTitle>
              <SheetDescription>
                Inscribe your site to Solana with IQLabs, then point a{" "}
                <span className="text-forge-dim">.sol</span> domain at it.
              </SheetDescription>
            </SheetHeader>

            {/* Wallet gate */}
            {!connected ? (
              <div className="mt-8 flex flex-col items-start gap-3 rounded-lg border border-border bg-card p-5">
                <p className="text-sm text-muted-foreground">
                  Connect a wallet to load your domains and sign.
                </p>
                <ConnectButton />
              </div>
            ) : (
              <>
                {/* Domain picker */}
                <div className="mt-6">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Target domain
                  </p>
                  {loading ? (
                    <p className="text-sm text-muted-foreground">
                      <Loader2 size={14} className="mr-1 inline animate-spin" />
                      Loading your .sol domains…
                    </p>
                  ) : error ? (
                    <p className="text-sm text-destructive">{error}</p>
                  ) : domains.length === 0 ? (
                    <div className="rounded-md border border-dashed border-border p-4 text-sm text-muted-foreground">
                      No .sol domains found for{" "}
                      <span className="font-mono">
                        {shortKey(publicKey?.toBase58())}
                      </span>
                      . Register one at{" "}
                      <a
                        href="https://sns.id"
                        target="_blank"
                        rel="noreferrer"
                        className="text-primary hover:underline"
                      >
                        sns.id
                      </a>{" "}
                      (in-app registration is a later phase).
                    </div>
                  ) : (
                    <div className="grid gap-2 sm:grid-cols-2">
                      {domains.map((d) => (
                        <button
                          key={d.pubkey}
                          onClick={() => setSelected(d.domain)}
                          className={cn(
                            "flex items-center gap-2 rounded-md border px-3 py-2 text-left text-sm transition-colors",
                            selected === d.domain
                              ? "border-primary bg-primary/10 text-foreground"
                              : "border-border bg-card hover:border-forge-muted",
                          )}
                        >
                          <Globe size={14} className="text-forge-dim" />
                          {d.domain}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Export preview */}
                <div className="mt-6">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Preview (exported HTML)
                  </p>
                  <div className="overflow-hidden rounded-lg border border-border bg-white">
                    <iframe
                      title="Export preview"
                      srcDoc={html}
                      className="h-72 w-full"
                      sandbox=""
                    />
                  </div>
                  <p className="mt-1 font-mono text-[11px] text-muted-foreground">
                    {(html.length / 1024).toFixed(1)} KB · {state.site.blocks.length}{" "}
                    blocks
                  </p>
                </div>

                {/* Mode */}
                <div className="mt-6">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    Mode
                  </p>
                  <div className="inline-flex rounded-md border border-border p-0.5">
                    {(["simulate", "live"] as PublishMode[]).map((m) => (
                      <button
                        key={m}
                        onClick={() => setMode(m)}
                        className={cn(
                          "rounded px-3 py-1.5 text-sm capitalize transition-colors",
                          mode === m
                            ? "bg-secondary text-foreground"
                            : "text-muted-foreground hover:text-foreground",
                        )}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    {mode === "simulate"
                      ? "Runs the real serialize step; on-chain writes are mocked (no wallet prompt, no SOL)."
                      : "Prompts your wallet to sign. Inscribes via IQLabs and writes the SNS record — needs SOL and the IQLabs program on this cluster."}
                  </p>
                </div>

                <Button
                  className="mt-6 w-full font-mono"
                  disabled={!canPublish}
                  onClick={handlePublish}
                >
                  {running ? (
                    <>
                      <Loader2 size={15} className="animate-spin" /> Publishing…
                    </>
                  ) : (
                    <>
                      <Rocket size={15} /> Publish{" "}
                      {selected ? `→ ${selected}` : ""}
                    </>
                  )}
                </Button>

                {/* Pipeline */}
                {(running || result || failure) && (
                  <>
                    <Separator className="my-6" />
                    <div className="rounded-lg border border-border bg-card p-4">
                      {STEPS.map((s) => (
                        <StepRow
                          key={s.id}
                          label={s.label}
                          status={steps[s.id]}
                          detail={details[s.id]}
                        />
                      ))}
                    </div>
                  </>
                )}

                {failure && (
                  <p className="mt-3 flex items-start gap-2 text-sm text-destructive">
                    <AlertCircle size={15} className="mt-0.5 shrink-0" />
                    {failure}
                  </p>
                )}

                {result && (
                  <div className="mt-4 space-y-2 rounded-lg border border-primary/30 bg-primary/5 p-4">
                    <p className="flex items-center gap-2 font-medium text-foreground">
                      <Check size={16} className="text-primary" /> Live at{" "}
                      <span className="text-primary">{result.domain}</span>
                    </p>
                    <ResultRow label="Content ref" value={result.contentRef} />
                    <ResultLink label="Inscription tx" sig={result.inscriptionTx} />
                    <ResultLink label="SNS record tx" sig={result.recordTx} />
                    {mode === "simulate" && (
                      <p className="pt-1 text-xs text-muted-foreground">
                        Simulated — switch to Live to write these on-chain.
                      </p>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

function ResultRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="max-w-[260px] truncate font-mono text-xs">{value}</span>
    </div>
  );
}

function ResultLink({ label, sig }: { label: string; sig: string }) {
  return (
    <div className="flex items-center justify-between gap-2 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <a
        href={explorerTx(sig)}
        target="_blank"
        rel="noreferrer"
        className="flex items-center gap-1 font-mono text-xs text-primary hover:underline"
      >
        {shortKey(sig, 6, 6)}
        <ExternalLink size={11} />
      </a>
    </div>
  );
}
