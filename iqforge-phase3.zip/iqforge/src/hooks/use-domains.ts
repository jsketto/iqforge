"use client";

import { useEffect, useState } from "react";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { getDomainsForOwner, type OwnedDomain } from "@/lib/sns";

export function useDomains() {
  const { connection } = useConnection();
  const { publicKey } = useWallet();

  const [domains, setDomains] = useState<OwnedDomain[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!publicKey) {
      setDomains([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);
    getDomainsForOwner(connection, publicKey)
      .then((d) => {
        if (!cancelled) setDomains(d);
      })
      .catch((e) => {
        if (!cancelled) setError((e as Error)?.message ?? "Failed to load domains");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [connection, publicKey]);

  return { domains, loading, error };
}
