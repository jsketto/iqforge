import type { Connection } from "@solana/web3.js";
import type { Site } from "@/lib/editor/types";
import { inscribe, type WalletSigner } from "@/lib/iqlabs";
import { setContentRecord } from "@/lib/sns";
import { serializeSiteToHtml } from "./serialize";

export type PublishMode = "live" | "simulate";
export type StepId = "serialize" | "inscribe" | "record" | "done";
export type StepStatus = "pending" | "active" | "done" | "error";

export interface StepUpdate {
  step: StepId;
  status: StepStatus;
  detail?: string;
}

export interface PublishResult {
  html: string;
  /** content reference written into the SNS record */
  contentRef: string;
  /** IQLabs codeIn tx signature */
  inscriptionTx: string;
  /** SNS record-update tx signature */
  recordTx: string;
  domain: string;
}

export interface PublishOptions {
  connection: Connection;
  wallet: WalletSigner;
  site: Site;
  domain: string;
  mode: PublishMode;
  /** Reference scheme written to the SNS Url record. */
  refScheme?: string; // default "iqlabs"
  onStep?: (u: StepUpdate) => void;
}

const fakeSig = () =>
  Array.from({ length: 88 }, () =>
    "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz".charAt(
      Math.floor(Math.random() * 58),
    ),
  ).join("");

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * The full publish pipeline. In "simulate" mode it runs the real serialize
 * step and fakes the two on-chain writes (no wallet prompt, no SOL spent) so
 * the flow is fully demoable. In "live" mode it inscribes via IQLabs and writes
 * the SNS Url record, prompting the wallet to sign.
 */
export async function publishSite(opts: PublishOptions): Promise<PublishResult> {
  const { connection, wallet, site, domain, mode, onStep } = opts;
  const scheme = opts.refScheme ?? "iqlabs";
  const emit = (step: StepId, status: StepStatus, detail?: string) =>
    onStep?.({ step, status, detail });

  // 1) Serialize
  emit("serialize", "active");
  const html = serializeSiteToHtml(site);
  emit("serialize", "done", `${(html.length / 1024).toFixed(1)} KB`);

  // 2) Inscribe on-chain (IQLabs codeIn)
  emit("inscribe", "active");
  let inscriptionTx: string;
  try {
    if (mode === "live") {
      inscriptionTx = await inscribe(
        connection,
        wallet,
        html,
        "site.html",
        (pct) => emit("inscribe", "active", `${Math.round(pct)}%`),
      );
    } else {
      await wait(700);
      inscriptionTx = fakeSig();
    }
  } catch (e) {
    emit("inscribe", "error", (e as Error).message);
    throw e;
  }
  emit("inscribe", "done", inscriptionTx);

  const contentRef = `${scheme}://${inscriptionTx}`;

  // 3) Point the domain at it (SNS Url record)
  emit("record", "active");
  let recordTx: string;
  try {
    if (mode === "live") {
      recordTx = await setContentRecord(connection, wallet, domain, contentRef);
    } else {
      await wait(600);
      recordTx = fakeSig();
    }
  } catch (e) {
    emit("record", "error", (e as Error).message);
    throw e;
  }
  emit("record", "done", recordTx);

  emit("done", "done");
  return { html, contentRef, inscriptionTx, recordTx, domain };
}
