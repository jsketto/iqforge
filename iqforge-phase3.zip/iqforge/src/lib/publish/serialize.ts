import type { Block, Site } from "@/lib/editor/types";

// Serializes a Site into a single self-contained HTML document with inline CSS
// and no framework runtime — so the inscribed artifact is permanent and
// resolves anywhere, matching the "eternal site" goal. Mirrors the canvas
// block renderers' visual intent in plain HTML.
//
// (Known tradeoff: block visuals are defined twice — React for the editor,
// HTML here for export. A future refactor can drive both from one schema.)

const esc = (v: unknown): string =>
  String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const align = (v: unknown): string =>
  v === "center" ? "center" : v === "right" ? "right" : "left";

function radius(v: unknown): string {
  if (v === "full") return "9999px";
  if (v === "none") return "0";
  if (v === "md") return "8px";
  return "14px";
}

function renderBlock(b: Block): string {
  const p = b.props;
  switch (b.type) {
    case "hero":
      return `<section style="padding:80px 32px;background:${esc(p.bg ?? "#0b1120")};color:${esc(p.textColor ?? "#fff")}">
  <div style="max-width:640px;margin:0 auto;text-align:${align(p.align ?? "center")}">
    <h1 style="font-size:48px;line-height:1.1;font-weight:800;margin:0">${esc(p.heading)}</h1>
    <p style="font-size:18px;opacity:.8;margin:16px 0 0">${esc(p.subheading)}</p>
    <a href="${esc(p.ctaHref ?? "#")}" style="display:inline-block;margin-top:32px;background:#fff;color:#000;padding:12px 24px;border-radius:10px;font-weight:600;text-decoration:none">${esc(p.ctaLabel ?? "Get started")}</a>
  </div>
</section>`;
    case "heading":
      return `<h2 style="padding:16px 32px;font-size:30px;font-weight:700;color:#171717;text-align:${align(p.align)};margin:0">${esc(p.text)}</h2>`;
    case "paragraph":
      return `<p style="padding:12px 32px;font-size:16px;line-height:1.7;color:#404040;text-align:${align(p.align)};margin:0">${esc(p.text)}</p>`;
    case "image":
      return `<div style="padding:16px 32px"><img src="${esc(p.src)}" alt="${esc(p.alt)}" style="display:block;width:100%;height:auto;border-radius:${radius(p.rounded)}" /></div>`;
    case "button": {
      const solid = p.variant !== "outline";
      const style = solid
        ? "background:#171717;color:#fff;border:1px solid #171717"
        : "background:transparent;color:#171717;border:1px solid #171717";
      return `<div style="padding:16px 32px;text-align:${align(p.align)}"><a href="${esc(p.href ?? "#")}" style="display:inline-block;${style};padding:10px 20px;border-radius:10px;font-weight:500;text-decoration:none">${esc(p.label)}</a></div>`;
    }
    case "divider": {
      const pad = p.spacing === "lg" ? "32px" : p.spacing === "sm" ? "8px" : "16px";
      return `<div style="padding:${pad} 32px"><hr style="border:none;border-top:1px solid #e5e5e5;margin:0" /></div>`;
    }
    case "nft-gallery": {
      const cols = p.columns === "2" ? 2 : p.columns === "4" ? 4 : 3;
      const tiles = Array.from({ length: 6 })
        .map(
          () =>
            `<div style="aspect-ratio:1;border-radius:10px;background:linear-gradient(135deg,#e5e5e5,#d4d4d4)"></div>`,
        )
        .join("");
      return `<div style="padding:24px 32px">
  <h3 style="font-size:20px;font-weight:600;color:#171717;margin:0 0 16px">${esc(p.title ?? "My Collection")}</h3>
  <div style="display:grid;grid-template-columns:repeat(${cols},1fr);gap:12px">${tiles}</div>
</div>`;
    }
    case "wallet-connect":
      // Static button in the exported artifact; runtime wallet logic is added
      // when we ship the on-chain site runtime (later phase).
      return `<div style="padding:16px 32px"><button style="display:inline-flex;align-items:center;gap:8px;background:#00ff66;color:#050805;padding:10px 20px;border:none;border-radius:9999px;font-weight:600;cursor:pointer">${esc(p.label ?? "Connect Wallet")}</button></div>`;
    default:
      return "";
  }
}

export function serializeSiteToHtml(site: Site): string {
  const body = site.blocks.map(renderBlock).join("\n");
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="generator" content="IQForge" />
<title>${esc(site.name || "IQForge site")}</title>
<style>
  *{box-sizing:border-box}
  html,body{margin:0;padding:0}
  body{font-family:ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:#fff;color:#171717}
  img{max-width:100%}
</style>
</head>
<body>
${body}
</body>
</html>`;
}

/** Compact JSON representation of the project (for re-editing / versioning). */
export function serializeSiteToJson(site: Site): string {
  return JSON.stringify(site);
}