import type {
  Connection,
  PublicKey,
  Transaction,
  VersionedTransaction,
} from "@solana/web3.js";
import { RPC_URL } from "@/lib/solana";

// ─────────────────────────────────────────────────────────────────────────
// IQLabs on-chain storage (verified against @iqlabs-official/solana-sdk@0.1.27)
//
//   writer.codeIn({ connection, signer }, data, filename?, method?, filetype?, onProgress?)
//     -> Promise<txSignature>
//   reader.readCodeIn(txSignature) -> { metadata, data }
//
// The SDK's SignerInput accepts `Signer | Keypair | WalletSigner`, and its
// WalletSigner is exactly the wallet-adapter shape below — so the connected
// browser wallet IS the signer. No burner keypair required.
// ─────────────────────────────────────────────────────────────────────────

export interface WalletSigner {
  publicKey: PublicKey;
  signTransaction: <T extends Transaction | VersionedTransaction>(
    tx: T,
  ) => Promise<T>;
  signAllTransactions: <T extends Transaction | VersionedTransaction>(
    txs: T[],
  ) => Promise<T[]>;
}

let rpcConfigured = false;

async function loadSdk() {
  const sdk = await import("@iqlabs-official/solana-sdk");
  if (!rpcConfigured) {
    try {
      sdk.setRpcUrl(RPC_URL);
    } catch {
      /* setRpcUrl is best-effort */
    }
    rpcConfigured = true;
  }
  return sdk;
}

/** Inscribe a site bundle on-chain. Returns the codeIn tx signature. */
export async function inscribe(
  connection: Connection,
  signer: WalletSigner,
  data: string,
  filename = "site.html",
  onProgress?: (percent: number) => void,
): Promise<string> {
  const { writer } = await loadSdk();
  return writer.codeIn(
    { connection, signer },
    data,
    filename,
    0, // method: let the SDK pick small/medium/large
    "text/html",
    onProgress,
  );
}

/** Read a previously inscribed bundle back by tx signature. */
export async function readInscription(
  txSignature: string,
): Promise<{ metadata: string; data: string | null }> {
  const { reader } = await loadSdk();
  return reader.readCodeIn(txSignature);
}
