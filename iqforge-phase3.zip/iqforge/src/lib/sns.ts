import { Connection, PublicKey, Transaction } from "@solana/web3.js";
import type { WalletSigner } from "./iqlabs";

// Verified against @bonfida/spl-name-service@3.0.21:
//   getDomainKeysWithReverses(connection, wallet) -> { pubKey, domain }[]
//   createRecordV2Instruction(domain, Record, content, owner, payer) -> ix
//   updateRecordV2Instruction(domain, Record, content, owner, payer) -> ix
//   getRecordV2(connection, domain, Record) -> { deserializedContent?, ... } (throws if absent)
//   Record.Url / Record.IPFS / Record.ARWV / Record.SHDW ...

async function loadSns() {
  return import("@bonfida/spl-name-service");
}

const stripSol = (d: string) => d.replace(/\.sol$/i, "");

export interface OwnedDomain {
  /** e.g. "myproject.sol" */
  domain: string;
  /** domain account pubkey (base58) */
  pubkey: string;
}

/** List the `.sol` domains owned by a wallet (for the publish target picker). */
export async function getDomainsForOwner(
  connection: Connection,
  owner: PublicKey,
): Promise<OwnedDomain[]> {
  const sns = await loadSns();
  const rows = await sns.getDomainKeysWithReverses(connection, owner);
  return rows
    .filter((r) => Boolean(r.domain))
    .map((r) => ({ domain: `${r.domain}.sol`, pubkey: r.pubKey.toBase58() }));
}

/** Read the current Url-record content of a domain, or null if unset. */
export async function readUrlRecord(
  connection: Connection,
  domain: string,
): Promise<string | null> {
  const sns = await loadSns();
  try {
    const res = await sns.getRecordV2(connection, stripSol(domain), sns.Record.Url);
    return res.deserializedContent ?? null;
  } catch {
    return null; // record doesn't exist yet
  }
}

/**
 * Point a `.sol` domain at published content by writing the Url record (V2).
 * Creates the record if absent, otherwise updates it. Signed by the connected
 * wallet (which must own the domain). Returns the tx signature.
 *
 * NOTE FOR DEVS: which record the IQLabs resolver/gateway reads is still TBD
 * (Url vs a custom record). We write Record.Url by default — change `record`
 * here once the resolution convention is confirmed.
 */
export async function setContentRecord(
  connection: Connection,
  wallet: WalletSigner,
  domain: string,
  content: string,
): Promise<string> {
  const sns = await loadSns();
  const name = stripSol(domain);
  const owner = wallet.publicKey;

  const exists = await readUrlRecord(connection, domain).then((v) => v !== null);
  const ix = exists
    ? sns.updateRecordV2Instruction(name, sns.Record.Url, content, owner, owner)
    : sns.createRecordV2Instruction(name, sns.Record.Url, content, owner, owner);

  const tx = new Transaction().add(ix);
  tx.feePayer = owner;
  tx.recentBlockhash = (await connection.getLatestBlockhash()).blockhash;

  const signed = await wallet.signTransaction(tx);
  const sig = await connection.sendRawTransaction(signed.serialize());
  await connection.confirmTransaction(sig, "confirmed");
  return sig;
}
