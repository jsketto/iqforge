# IQForge

On-chain website builder for IQLabs. Drag-and-drop sites, inscribed on Solana
via the IQLabs SDK and pointed at your `.sol` domain through SNS.

## Stack

- Next.js 15 (App Router) + TypeScript + Tailwind
- `@solana/wallet-adapter-*` — Phantom & Solflare
- `@bonfida/spl-name-service` + `@bonfida/sns-react` — SNS (wired in Phase 3)
- `@iqlabs-official/solana-sdk` — on-chain storage (wired in Phase 3, see note)

## Run

```bash
npm install
cp .env.local.example .env.local   # add a real RPC URL
npm run dev                         # http://localhost:3000
```

Connect Phantom/Solflare via the top-right button. Routes: `/dashboard`,
`/editor`, `/sites`.

## Architecture (the important bit)

The IQLabs SDK is **not** an SNS tool — it's an inscription-based on-chain
storage + database layer (~2000× cheaper than normal writes). That reshapes the
publish flow:

```
editor → serialize Site (JSON/HTML)
       → iqlabs.writer.codeIn() inscribes it ON-CHAIN  → tx signature
       → write that signature/URL into the .sol domain's SNS record
```

So both the **content and the domain live on Solana** — no IPFS host required
(IPFS remains an optional fallback target). The SDK's on-chain DB tables
(`createTable`/`writeRow`/`readTableRows`) can also store the user's project
list, replacing Supabase.

Integration seams are isolated so later phases just fill them in:

- `src/lib/iqlabs.ts` — `inscribeSite()` / `readSite()` (stubbed; see note below)
- `src/lib/sns.ts` — `resolveDomainOwner()` / `getDomainsForOwner()`
- `src/lib/solana.ts` — connection + RPC config
- `src/types/project.ts` — the `Site` / `Block` model everything codes against

### Note on the IQLabs package

`@iqlabs-official/solana-sdk` is intentionally **kept out of `package.json`** for
now so Phase 1 installs cleanly. `src/lib/iqlabs.ts` defines the exact function
contract and throws a clear "not wired" error until Phase 3, where we confirm
the published name/version with the IQLabs devs, add the dep, and enable the
dynamic import (the Phase-3 lines are already written as comments).

## Roadmap

- **Phase 1 (this)** — scaffold, wallet adapter, routing. ✅
- **Phase 2** — drag-and-drop editor (@dnd-kit), block library, properties panel.
- **Phase 3** — SNS login + publish (codeIn inscription → SNS record).
- **Phase 4** — AI section generation (Claude) via a server route.
- **Phase 5** — templates, responsive, payments/token gating.
