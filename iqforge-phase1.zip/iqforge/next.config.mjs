/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Solana web3.js and the wallet adapters pull in node-ish globals.
  // These fallbacks keep the browser bundle happy.
  webpack: (config) => {
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      path: false,
      crypto: false,
    };
    config.externals = config.externals || [];
    config.externals.push("pino-pretty", "lokijs", "encoding");
    return config;
  },

  // Phase 3 (Publish): the editor's preview/export step produces a static
  // bundle that gets inscribed on-chain via iqlabs.codeIn() and/or pinned to
  // IPFS. When we wire that up we flip this on for the *generated site* output,
  // not the builder app itself. Left commented so `next dev` stays full-featured.
  // output: "export",
  // images: { unoptimized: true },
};

export default nextConfig;
