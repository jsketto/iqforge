// Core domain model for IQForge.
// A "Site" is the user-authored project; "blocks" are the drag-and-drop
// components placed on the canvas (Phase 2 fills these in). The same Site
// object is what gets serialized, inscribed on-chain (iqlabs.codeIn) and
// pointed to by an SNS record (Phase 3).

export type BlockKind =
  | "hero"
  | "text"
  | "image"
  | "embed"
  | "wallet-button"
  | "nft-gallery"
  | "token-widget"
  | "payment-button";

export interface Block {
  id: string;
  kind: BlockKind;
  /** Free-form props per block kind; typed per-kind in Phase 2. */
  props: Record<string, unknown>;
}

export type PublishTarget = "onchain" | "ipfs";

export interface PublishRecord {
  target: PublishTarget;
  /** iqlabs codeIn tx signature when target = "onchain". */
  txSignature?: string;
  /** IPFS CID when target = "ipfs". */
  cid?: string;
  /** The .sol domain the record was written to. */
  domain?: string;
  publishedAt: number;
}

export interface Site {
  id: string;
  name: string;
  /** Wallet pubkey (base58) of the owner. */
  owner: string;
  /** Optional .sol domain this site is bound to. */
  domain?: string;
  blocks: Block[];
  template?: TemplateId;
  createdAt: number;
  updatedAt: number;
  lastPublish?: PublishRecord;
}

export type TemplateId =
  | "blank"
  | "landing"
  | "nft-mint"
  | "profile"
  | "dapp-dashboard";

export interface TemplateMeta {
  id: TemplateId;
  name: string;
  description: string;
  /** True if this template requires a paid unlock (Phase 5 / token gate). */
  premium: boolean;
}
