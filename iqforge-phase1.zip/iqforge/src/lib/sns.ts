import { Connection, PublicKey } from "@solana/web3.js";

// Thin wrappers around @bonfida/spl-name-service (v3). Phase 3 wires these
// into the publish + login flows; isolating them here keeps the SDK surface
// in one place if Bonfida's API shifts (the repo is marked "active development").
//
// We import through a loose shape so Phase 1 type-checks/builds cleanly even
// before we pin the exact v3 export names with the Bonfida docs in Phase 3.
type SnsModule = {
  resolve: (c: Connection, domain: string) => Promise<PublicKey>;
  getAllDomains: (c: Connection, owner: PublicKey) => Promise<PublicKey[]>;
  reverseLookup: (c: Connection, key: PublicKey) => Promise<string>;
};

async function loadSns(): Promise<SnsModule> {
  return (await import("@bonfida/spl-name-service")) as unknown as SnsModule;
}

/** Resolve the current owner of a `.sol` domain. Pass the name WITHOUT ".sol". */
export async function resolveDomainOwner(
  connection: Connection,
  domain: string,
): Promise<PublicKey | null> {
  try {
    const sns = await loadSns();
    return await sns.resolve(connection, domain.replace(/\.sol$/, ""));
  } catch {
    return null;
  }
}

/** List every `.sol` domain owned by a wallet (for SNS login / site binding). */
export async function getDomainsForOwner(
  connection: Connection,
  owner: PublicKey,
): Promise<string[]> {
  try {
    const sns = await loadSns();
    const keys = await sns.getAllDomains(connection, owner);
    const names = await Promise.all(
      keys.map((k) => sns.reverseLookup(connection, k).catch(() => null)),
    );
    return names.filter((n): n is string => Boolean(n)).map((n) => `${n}.sol`);
  } catch {
    return [];
  }
}
