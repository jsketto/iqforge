import type { Connection } from "@solana/web3.js";

// ─────────────────────────────────────────────────────────────────────────
// IQLabs on-chain storage seam.
//
// Per the IQLabs SDK docs (@iqlabs-official/solana-sdk):
//   iqlabs.writer.codeIn({ connection, signer }, data, filename?) -> txSig
//   iqlabs.reader.readCodeIn(txSig) -> { metadata, data }
//   iqlabs.utils.setRpcUrl(url)
//
// We DON'T hard-depend on the package yet (kept out of package.json) so Phase 1
// installs cleanly. The functions below throw a clear "not wired" error until
// Phase 3, where we: (1) confirm the exact published package name/version with
// the IQLabs devs, (2) add it as a dependency, (3) replace the dynamic import
// below. The signatures here are the contract the rest of the app codes against.
// ─────────────────────────────────────────────────────────────────────────

export interface IqSigner {
  publicKey: import("@solana/web3.js").PublicKey;
  signMessage?: (msg: Uint8Array) => Promise<Uint8Array>;
  // codeIn expects a Solana Signer-compatible object; wallet-adapter wallets
  // are adapted in Phase 3.
}

const NOT_WIRED =
  "IQLabs SDK not wired yet (Phase 3). Confirm package name/version with IQLabs devs, " +
  "then enable the dynamic import in src/lib/iqlabs.ts.";

/** Inscribe a site bundle on-chain. Returns the codeIn tx signature. */
export async function inscribeSite(
  _connection: Connection,
  _signer: IqSigner,
  _data: string,
  _filename = "site.json",
): Promise<string> {
  // Phase 3:
  // const iqlabs = (await import("@iqlabs-official/solana-sdk")).default;
  // return iqlabs.writer.codeIn({ connection: _connection, signer: _signer }, _data, _filename);
  throw new Error(NOT_WIRED);
}

/** Read a previously inscribed site bundle back by tx signature. */
export async function readSite(
  _txSignature: string,
): Promise<{ metadata: string; data: string | null }> {
  // Phase 3:
  // const iqlabs = (await import("@iqlabs-official/solana-sdk")).default;
  // return iqlabs.reader.readCodeIn(_txSignature);
  throw new Error(NOT_WIRED);
}
