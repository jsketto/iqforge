import { Connection, clusterApiUrl } from "@solana/web3.js";

export type Cluster = "mainnet-beta" | "devnet";

export const CLUSTER: Cluster =
  (process.env.NEXT_PUBLIC_SOLANA_CLUSTER as Cluster) ?? "devnet";

/**
 * Prefer a dedicated RPC (Helius/Triton/QuickNode) via env — the public
 * clusterApiUrl endpoints are rate-limited and will not survive the
 * signature-history reads that both SNS and IQLabs' readers do.
 */
export const RPC_URL =
  process.env.NEXT_PUBLIC_SOLANA_RPC_URL ?? clusterApiUrl(CLUSTER);

let _connection: Connection | null = null;

export function getConnection(): Connection {
  if (!_connection) {
    _connection = new Connection(RPC_URL, "confirmed");
  }
  return _connection;
}
