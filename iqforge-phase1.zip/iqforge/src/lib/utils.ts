import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Shorten a base58 pubkey for display: "7sF2…PZ5E". */
export function shortKey(key?: string | null, lead = 4, tail = 4): string {
  if (!key) return "";
  if (key.length <= lead + tail) return key;
  return `${key.slice(0, lead)}…${key.slice(-tail)}`;
}
