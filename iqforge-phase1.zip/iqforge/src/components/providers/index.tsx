"use client";

import type { ReactNode } from "react";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SolanaWalletProvider } from "./wallet-provider";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <SolanaWalletProvider>
      <TooltipProvider delayDuration={200}>{children}</TooltipProvider>
    </SolanaWalletProvider>
  );
}
