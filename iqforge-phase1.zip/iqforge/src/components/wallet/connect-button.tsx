"use client";

import dynamic from "next/dynamic";

// WalletMultiButton reads `window`/wallet state at render time, so it must be
// client-only — importing it with ssr:false prevents hydration mismatches.
export const ConnectButton = dynamic(
  async () =>
    (await import("@solana/wallet-adapter-react-ui")).WalletMultiButton,
  {
    ssr: false,
    loading: () => (
      <div className="h-10 w-36 animate-pulse rounded-md border border-forge-muted/40 bg-ink-700" />
    ),
  },
);
