"use client";

import type { ReactNode } from "react";
import Link from "next/link";
import { Zap } from "lucide-react";
import { SidebarNav } from "./sidebar-nav";
import { ConnectButton } from "@/components/wallet/connect-button";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden w-60 shrink-0 flex-col border-r border-ink-600 bg-ink-800/60 md:flex">
        <Link
          href="/dashboard"
          className="flex items-center gap-2 border-b border-ink-600 px-5 py-4"
        >
          <Zap size={18} className="text-forge" fill="currentColor" />
          <span className="font-display text-lg font-semibold tracking-tight text-zinc-100">
            IQ<span className="text-forge">Forge</span>
          </span>
        </Link>
        <SidebarNav />
        <div className="mt-auto px-5 py-4">
          <p className="font-mono text-[10px] leading-relaxed text-zinc-600">
            on-chain sites · powered by IQLabs inscriptions + SNS
          </p>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b border-ink-600 bg-ink-800/40 px-6 backdrop-blur">
          <div className="font-mono text-xs text-zinc-500">
            {/* Phase 3: swap for resolved .sol domain when connected */}
            devnet · alpha
          </div>
          <ConnectButton />
        </header>
        <main className="flex-1 overflow-y-auto bg-grid [background-size:32px_32px]">
          {children}
        </main>
      </div>
    </div>
  );
}
