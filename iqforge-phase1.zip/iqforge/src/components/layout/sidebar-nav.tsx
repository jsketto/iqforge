"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, PenSquare, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/editor", label: "Editor", icon: PenSquare },
  { href: "/sites", label: "My Sites", icon: Globe },
] as const;

export function SidebarNav() {
  const pathname = usePathname();

  return (
    <nav className="flex flex-col gap-1 px-3 py-4">
      {NAV.map(({ href, label, icon: Icon }) => {
        const active = pathname === href || pathname.startsWith(`${href}/`);
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
              active
                ? "bg-forge/10 text-forge shadow-forge"
                : "text-zinc-400 hover:bg-ink-700 hover:text-zinc-100",
            )}
          >
            <Icon
              size={18}
              className={cn(
                "transition-colors",
                active ? "text-forge" : "text-zinc-500 group-hover:text-zinc-300",
              )}
            />
            <span className="font-mono tracking-tight">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
