"use client";

import Link from "next/link";
import { useWallet } from "@solana/wallet-adapter-react";
import { Globe, Plus } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";

export default function SitesPage() {
  const { connected } = useWallet();

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-6 py-10">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-forge-dim">
              My Sites
            </p>
            <h1 className="mt-2 font-display text-3xl font-semibold text-foreground">
              Published & drafts
            </h1>
          </div>
          <Button asChild className="font-mono">
            <Link href="/editor">
              <Plus size={16} /> New
            </Link>
          </Button>
        </div>

        {!connected ? (
          <p className="text-sm text-muted-foreground">
            Connect your wallet to see sites tied to your address.
          </p>
        ) : (
          // Phase 3: read the user's sites from the IQLabs DbRoot table
          // (writeRow/readTableRows) keyed by owner pubkey.
          <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-20 text-center">
            <Globe className="mb-3 text-muted-foreground" size={28} />
            <p className="text-sm text-muted-foreground">No sites yet.</p>
            <Button asChild variant="link" className="mt-1 text-primary">
              <Link href="/editor">Build your first →</Link>
            </Button>
          </div>
        )}
      </div>
    </AppShell>
  );
}
