import { redirect } from "next/navigation";

// Entry point → dashboard. (A marketing landing page can live here later.)
export default function Home() {
  redirect("/dashboard");
}
