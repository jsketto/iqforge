"use client";

import Link from "next/link";
import { useWallet } from "@solana/wallet-adapter-react";
import { PenSquare, Globe, Wallet } from "lucide-react";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { shortKey } from "@/lib/utils";

export default function DashboardPage() {
  const { connected, publicKey } = useWallet();

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-6 py-10">
        <header className="mb-10">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-forge-dim">
            Dashboard
          </p>
          <h1 className="mt-2 font-display text-3xl font-semibold text-foreground">
            {connected ? (
              <>
                Wallet linked:{" "}
                <span className="text-primary">
                  {shortKey(publicKey?.toBase58())}
                </span>
              </>
            ) : (
              <>Forge an on-chain site.</>
            )}
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Build with drag-and-drop, inscribe the result on Solana via IQLabs,
            and point your <span className="text-forge-dim">.sol</span> domain at
            it. No servers, no host.
          </p>
        </header>

        {!connected ? (
          <Card className="shadow-forge">
            <CardHeader>
              <Wallet className="mb-2 text-primary" size={28} />
              <CardTitle className="font-display text-lg">
                Connect a wallet to begin
              </CardTitle>
              <CardDescription>
                Phantom or Solflare. We&apos;ll pull your{" "}
                <span className="text-forge-dim">.sol</span> domains in Phase 3.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="font-mono text-xs text-muted-foreground">
                ↗ use the Connect button in the top-right
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            <QuickCard
              href="/editor"
              icon={<PenSquare className="text-primary" size={22} />}
              title="New site"
              body="Open the editor and drop in a hero, gallery, or token widget."
            />
            <QuickCard
              href="/sites"
              icon={<Globe className="text-primary" size={22} />}
              title="My sites"
              body="See everything you've published on-chain and re-deploy."
            />
          </div>
        )}
      </div>
    </AppShell>
  );
}

function QuickCard({
  href,
  icon,
  title,
  body,
}: {
  href: string;
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <Link href={href} className="group">
      <Card className="h-full transition-colors hover:border-forge-muted hover:bg-accent/40">
        <CardHeader>
          <div className="mb-2">{icon}</div>
          <CardTitle className="font-display text-lg group-hover:text-primary">
            {title}
          </CardTitle>
          <CardDescription>{body}</CardDescription>
        </CardHeader>
      </Card>
    </Link>
  );
}
