"use client";

import { AppShell } from "@/components/layout/app-shell";
import { Square, Type, Image as ImageIcon, Code2, Wallet, GripVertical } from "lucide-react";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

// Phase 1: static three-pane shell wired with shadcn primitives
// (Component Library · Canvas · Properties Panel).
// Phase 2 makes the library items draggable (@dnd-kit + Framer Motion) and the
// canvas a drop target bound to the Block[] model.
const LIBRARY = [
  { kind: "hero", label: "Hero", icon: Square },
  { kind: "text", label: "Text", icon: Type },
  { kind: "image", label: "Image", icon: ImageIcon },
  { kind: "embed", label: "Embed", icon: Code2 },
  { kind: "wallet-button", label: "Wallet Button", icon: Wallet },
] as const;

export default function EditorPage() {
  return (
    <AppShell>
      <div className="grid h-full grid-cols-1 lg:grid-cols-[240px_1fr_300px]">
        {/* Component Library */}
        <div className="hidden border-r border-border bg-card/40 lg:flex lg:flex-col">
          <div className="px-4 py-4">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Components
            </p>
          </div>
          <Separator />
          <ScrollArea className="flex-1 px-4 py-4">
            <div className="space-y-2">
              {LIBRARY.map(({ kind, label, icon: Icon }) => (
                <Tooltip key={kind}>
                  <TooltipTrigger asChild>
                    <Card className="flex cursor-grab items-center gap-3 rounded-md px-3 py-2 text-sm text-foreground/80 shadow-none transition-colors hover:border-forge-muted hover:bg-accent">
                      <GripVertical size={14} className="text-muted-foreground" />
                      <Icon size={16} className="text-forge-dim" />
                      {label}
                    </Card>
                  </TooltipTrigger>
                  <TooltipContent side="right">
                    Drag-and-drop arrives in Phase 2
                  </TooltipContent>
                </Tooltip>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Canvas */}
        <div className="flex items-center justify-center p-8">
          <div className="flex h-full max-h-[640px] w-full max-w-2xl flex-col items-center justify-center rounded-lg border-2 border-dashed border-border text-center">
            <p className="font-display text-lg text-muted-foreground">Canvas</p>
            <p className="mt-1 font-mono text-xs text-muted-foreground/70">
              Drag components here — wiring lands in Phase 2
            </p>
          </div>
        </div>

        {/* Properties Panel */}
        <div className="hidden border-l border-border bg-card/40 xl:flex xl:flex-col">
          <div className="px-4 py-4">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Properties
            </p>
          </div>
          <Separator />
          <div className="px-4 py-4">
            <Tabs defaultValue="design">
              <TabsList className="w-full">
                <TabsTrigger value="design" className="flex-1">
                  Design
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex-1">
                  Settings
                </TabsTrigger>
              </TabsList>
              <TabsContent value="design">
                <p className="px-1 py-3 text-sm text-muted-foreground">
                  Select a block to edit its design.
                </p>
              </TabsContent>
              <TabsContent value="settings">
                <p className="px-1 py-3 text-sm text-muted-foreground">
                  Block settings appear here.
                </p>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
