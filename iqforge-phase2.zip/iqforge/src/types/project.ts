// Publish-layer types. The core editor model (Block/Site/BlockType) lives in
// src/lib/editor/types.ts and is re-exported here so existing imports keep
// working; this file owns the Phase 3 publish + Phase 5 template types.

export type { Block, BlockType, Site, BlockProps, DeviceMode } from "@/lib/editor/types";

export type PublishTarget = "onchain" | "ipfs";

export interface PublishRecord {
  target: PublishTarget;
  /** iqlabs codeIn tx signature when target = "onchain". */
  txSignature?: string;
  /** IPFS CID when target = "ipfs". */
  cid?: string;
  /** The .sol domain the record was written to. */
  domain?: string;
  publishedAt: number;
}

export type TemplateId =
  | "blank"
  | "landing"
  | "nft-mint"
  | "profile"
  | "dapp-dashboard";

export interface TemplateMeta {
  id: TemplateId;
  name: string;
  description: string;
  /** True if this template requires a paid unlock (Phase 5 / token gate). */
  premium: boolean;
}
