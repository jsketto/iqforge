import { AppShell } from "@/components/layout/app-shell";
import { Editor } from "@/components/editor/editor";

export default function EditorPage() {
  return (
    <AppShell>
      <Editor />
    </AppShell>
  );
}
