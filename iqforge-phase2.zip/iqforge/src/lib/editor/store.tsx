"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  type ReactNode,
} from "react";
import { arrayMove } from "@dnd-kit/sortable";
import type { Block, BlockType, DeviceMode, Site } from "./types";
import { getDef } from "@/lib/blocks/registry";

const STORAGE_KEY = "iqforge:draft";

interface EditorState {
  site: Site;
  selectedId: string | null;
  device: DeviceMode;
  preview: boolean;
}

type Action =
  | { type: "LOAD_SITE"; site: Site }
  | { type: "SET_NAME"; name: string }
  | { type: "ADD_BLOCK"; blockType: BlockType; index?: number }
  | { type: "MOVE"; from: number; to: number }
  | { type: "UPDATE_PROPS"; id: string; patch: Record<string, unknown> }
  | { type: "DELETE"; id: string }
  | { type: "DUPLICATE"; id: string }
  | { type: "SELECT"; id: string | null }
  | { type: "SET_DEVICE"; device: DeviceMode }
  | { type: "SET_PREVIEW"; value: boolean };

function emptySite(): Site {
  // Deterministic for first render (avoids hydration mismatch); real id/timestamps
  // are assigned on the client in the provider effect.
  return { id: "draft", name: "Untitled site", blocks: [], createdAt: 0, updatedAt: 0 };
}

function newBlock(type: BlockType): Block {
  return { id: crypto.randomUUID(), type, props: getDef(type).defaultProps() };
}

const initialState: EditorState = {
  site: emptySite(),
  selectedId: null,
  device: "desktop",
  preview: false,
};

function touch(site: Site, blocks: Block[]): Site {
  return { ...site, blocks, updatedAt: Date.now() };
}

function reducer(state: EditorState, action: Action): EditorState {
  switch (action.type) {
    case "LOAD_SITE":
      return { ...state, site: action.site, selectedId: null };

    case "SET_NAME":
      return { ...state, site: { ...state.site, name: action.name, updatedAt: Date.now() } };

    case "ADD_BLOCK": {
      const block = newBlock(action.blockType);
      const blocks = [...state.site.blocks];
      const at = action.index ?? blocks.length;
      blocks.splice(Math.max(0, Math.min(at, blocks.length)), 0, block);
      return { ...state, site: touch(state.site, blocks), selectedId: block.id };
    }

    case "MOVE": {
      if (action.from === action.to) return state;
      const blocks = arrayMove(state.site.blocks, action.from, action.to);
      return { ...state, site: touch(state.site, blocks) };
    }

    case "UPDATE_PROPS": {
      const blocks = state.site.blocks.map((b) =>
        b.id === action.id ? { ...b, props: { ...b.props, ...action.patch } } : b,
      );
      return { ...state, site: touch(state.site, blocks) };
    }

    case "DELETE": {
      const blocks = state.site.blocks.filter((b) => b.id !== action.id);
      return {
        ...state,
        site: touch(state.site, blocks),
        selectedId: state.selectedId === action.id ? null : state.selectedId,
      };
    }

    case "DUPLICATE": {
      const idx = state.site.blocks.findIndex((b) => b.id === action.id);
      if (idx === -1) return state;
      const src = state.site.blocks[idx];
      const copy: Block = { id: crypto.randomUUID(), type: src.type, props: { ...src.props } };
      const blocks = [...state.site.blocks];
      blocks.splice(idx + 1, 0, copy);
      return { ...state, site: touch(state.site, blocks), selectedId: copy.id };
    }

    case "SELECT":
      return { ...state, selectedId: action.id };

    case "SET_DEVICE":
      return { ...state, device: action.device };

    case "SET_PREVIEW":
      return { ...state, preview: action.value, selectedId: action.value ? null : state.selectedId };

    default:
      return state;
  }
}

interface EditorContextValue {
  state: EditorState;
  selectedBlock: Block | null;
  setName: (name: string) => void;
  addBlock: (type: BlockType, index?: number) => void;
  move: (from: number, to: number) => void;
  updateProps: (id: string, patch: Record<string, unknown>) => void;
  remove: (id: string) => void;
  duplicate: (id: string) => void;
  select: (id: string | null) => void;
  setDevice: (device: DeviceMode) => void;
  setPreview: (value: boolean) => void;
}

const EditorContext = createContext<EditorContextValue | null>(null);

export function EditorProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // Load draft (or initialize a fresh site) on the client only.
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const site = JSON.parse(raw) as Site;
        if (site?.blocks) dispatch({ type: "LOAD_SITE", site });
        return;
      }
    } catch {
      /* ignore corrupt draft */
    }
    dispatch({
      type: "LOAD_SITE",
      site: { ...emptySite(), id: crypto.randomUUID(), createdAt: Date.now(), updatedAt: Date.now() },
    });
  }, []);

  // Debounced autosave of the draft.
  useEffect(() => {
    if (state.site.createdAt === 0) return; // not yet initialized
    const t = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state.site));
      } catch {
        /* storage full / unavailable */
      }
    }, 400);
    return () => clearTimeout(t);
  }, [state.site]);

  const value = useMemo<EditorContextValue>(
    () => ({
      state,
      selectedBlock: state.selectedId
        ? state.site.blocks.find((b) => b.id === state.selectedId) ?? null
        : null,
      setName: (name) => dispatch({ type: "SET_NAME", name }),
      addBlock: (blockType, index) => dispatch({ type: "ADD_BLOCK", blockType, index }),
      move: (from, to) => dispatch({ type: "MOVE", from, to }),
      updateProps: (id, patch) => dispatch({ type: "UPDATE_PROPS", id, patch }),
      remove: (id) => dispatch({ type: "DELETE", id }),
      duplicate: (id) => dispatch({ type: "DUPLICATE", id }),
      select: (id) => dispatch({ type: "SELECT", id }),
      setDevice: (device) => dispatch({ type: "SET_DEVICE", device }),
      setPreview: (value) => dispatch({ type: "SET_PREVIEW", value }),
    }),
    [state],
  );

  return <EditorContext.Provider value={value}>{children}</EditorContext.Provider>;
}

export function useEditor(): EditorContextValue {
  const ctx = useContext(EditorContext);
  if (!ctx) throw new Error("useEditor must be used within <EditorProvider>");
  return ctx;
}
