// Core editor data model for IQForge.
// A `Site` is the user's project; `blocks` is the ordered list rendered on the
// canvas. This same serialized shape is what gets inscribed on-chain via
// IQLabs `codeIn()` and pointed to by the SNS record in Phase 3.

export type BlockType =
  | "hero"
  | "heading"
  | "paragraph"
  | "image"
  | "button"
  | "divider"
  | "nft-gallery"
  | "wallet-connect";

export type BlockProps = Record<string, unknown>;

export interface Block<T extends BlockProps = BlockProps> {
  id: string;
  type: BlockType;
  props: T;
}

export type DeviceMode = "desktop" | "mobile";

export interface Site {
  id: string;
  name: string;
  /** Owner wallet pubkey (base58), set at publish time. */
  owner?: string;
  /** Bound .sol domain, set in Phase 3. */
  domain?: string;
  blocks: Block[];
  createdAt: number;
  updatedAt: number;
}
