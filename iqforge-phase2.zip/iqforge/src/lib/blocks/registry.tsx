import type { FC } from "react";
import type { LucideIcon } from "lucide-react";
import {
  LayoutPanelTop,
  Heading1,
  Pilcrow,
  Image as ImageIcon,
  MousePointerClick,
  Minus,
  Images,
  Wallet,
} from "lucide-react";
import type { BlockProps, BlockType, DeviceMode } from "@/lib/editor/types";

// ── Field schema (drives the Properties Panel — wired next phase) ────────────
export type FieldType =
  | "text"
  | "textarea"
  | "url"
  | "color"
  | "select"
  | "number";

export type FieldGroup = "design" | "settings" | "advanced";

export interface FieldDef {
  key: string;
  label: string;
  type: FieldType;
  group: FieldGroup;
  placeholder?: string;
  options?: { label: string; value: string }[];
}

export type LibraryCategory =
  | "Basics"
  | "Layout"
  | "Content"
  | "Web3"
  | "Media";

export const CATEGORY_ORDER: LibraryCategory[] = [
  "Basics",
  "Layout",
  "Content",
  "Media",
  "Web3",
];

export interface RenderProps {
  props: BlockProps;
  device?: DeviceMode;
}

export interface BlockDef {
  type: BlockType;
  label: string;
  icon: LucideIcon;
  category: LibraryCategory;
  description: string;
  defaultProps: () => BlockProps;
  fields: FieldDef[];
  Render: FC<RenderProps>;
}

// ── helpers ──────────────────────────────────────────────────────────────────
const str = (v: unknown, d = ""): string => (typeof v === "string" ? v : d);
const alignClass = (v: unknown): string =>
  v === "center" ? "text-center" : v === "right" ? "text-right" : "text-left";
const ALIGN_OPTS = [
  { label: "Left", value: "left" },
  { label: "Center", value: "center" },
  { label: "Right", value: "right" },
];

// ── Renderers (target a normal white "page" surface — this is the USER's site,
//    not the IQForge chrome) ──────────────────────────────────────────────────
const HeroRender: FC<RenderProps> = ({ props }) => {
  const bg = str(props.bg, "#0b1120");
  const fg = str(props.textColor, "#ffffff");
  return (
    <section
      className="px-8 py-20"
      style={{ backgroundColor: bg, color: fg }}
    >
      <div className={`mx-auto max-w-2xl ${alignClass(props.align ?? "center")}`}>
        <h1 className="text-4xl font-bold leading-tight sm:text-5xl">
          {str(props.heading, "Build on Solana, forever.")}
        </h1>
        <p className="mt-4 text-lg opacity-80">
          {str(
            props.subheading,
            "Your site, inscribed on-chain and resolved by your .sol domain.",
          )}
        </p>
        <a
          href={str(props.ctaHref, "#")}
          className="mt-8 inline-block rounded-lg bg-white px-6 py-3 font-semibold text-black no-underline"
        >
          {str(props.ctaLabel, "Get started")}
        </a>
      </div>
    </section>
  );
};

const HeadingRender: FC<RenderProps> = ({ props }) => (
  <h2
    className={`px-8 py-4 text-3xl font-bold text-neutral-900 ${alignClass(props.align)}`}
  >
    {str(props.text, "Section heading")}
  </h2>
);

const ParagraphRender: FC<RenderProps> = ({ props }) => (
  <p
    className={`px-8 py-3 text-base leading-relaxed text-neutral-700 ${alignClass(props.align)}`}
  >
    {str(
      props.text,
      "Write something compelling about your project here. Click to select and edit.",
    )}
  </p>
);

const ImageRender: FC<RenderProps> = ({ props }) => {
  const rounded =
    props.rounded === "full"
      ? "rounded-full"
      : props.rounded === "none"
        ? "rounded-none"
        : props.rounded === "md"
          ? "rounded-md"
          : "rounded-xl";
  return (
    <div className="px-8 py-4">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={str(
          props.src,
          "https://placehold.co/1200x600/0b1120/00ff66?text=Your+image",
        )}
        alt={str(props.alt, "")}
        className={`mx-auto block h-auto w-full ${rounded}`}
      />
    </div>
  );
};

const ButtonRender: FC<RenderProps> = ({ props }) => {
  const solid = props.variant !== "outline";
  return (
    <div className={`px-8 py-4 ${alignClass(props.align)}`}>
      <a
        href={str(props.href, "#")}
        className={
          solid
            ? "inline-block rounded-lg bg-neutral-900 px-5 py-2.5 font-medium text-white no-underline"
            : "inline-block rounded-lg border border-neutral-900 px-5 py-2.5 font-medium text-neutral-900 no-underline"
        }
      >
        {str(props.label, "Click me")}
      </a>
    </div>
  );
};

const DividerRender: FC<RenderProps> = ({ props }) => {
  const pad =
    props.spacing === "lg" ? "py-8" : props.spacing === "sm" ? "py-2" : "py-4";
  return (
    <div className={`px-8 ${pad}`}>
      <hr className="border-neutral-200" />
    </div>
  );
};

const NftGalleryRender: FC<RenderProps> = ({ props }) => {
  const cols = str(props.columns, "3");
  const count = 6;
  const gridCols =
    cols === "2"
      ? "grid-cols-2"
      : cols === "4"
        ? "grid-cols-2 sm:grid-cols-4"
        : "grid-cols-2 sm:grid-cols-3";
  return (
    <div className="px-8 py-6">
      <h3 className="mb-4 text-xl font-semibold text-neutral-900">
        {str(props.title, "My Collection")}
      </h3>
      <div className={`grid gap-3 ${gridCols}`}>
        {Array.from({ length: count }).map((_, i) => (
          <div
            key={i}
            className="aspect-square rounded-lg bg-gradient-to-br from-neutral-200 to-neutral-300"
          />
        ))}
      </div>
      <p className="mt-3 text-xs text-neutral-400">
        Live NFTs load on publish (Phase 3).
      </p>
    </div>
  );
};

const WalletConnectRender: FC<RenderProps> = ({ props }) => (
  <div className="px-8 py-4">
    <button
      type="button"
      className="inline-flex items-center gap-2 rounded-full bg-[#00ff66] px-5 py-2.5 font-semibold text-[#050805]"
    >
      <Wallet size={16} />
      {str(props.label, "Connect Wallet")}
    </button>
  </div>
);

// ── Registry ──────────────────────────────────────────────────────────────────
export const BLOCK_DEFS: BlockDef[] = [
  {
    type: "hero",
    label: "Hero",
    icon: LayoutPanelTop,
    category: "Layout",
    description: "Full-width banner with heading + CTA",
    defaultProps: () => ({
      heading: "Build on Solana, forever.",
      subheading:
        "Your site, inscribed on-chain and resolved by your .sol domain.",
      ctaLabel: "Get started",
      ctaHref: "#",
      bg: "#0b1120",
      textColor: "#ffffff",
      align: "center",
    }),
    fields: [
      { key: "heading", label: "Heading", type: "text", group: "design" },
      { key: "subheading", label: "Subheading", type: "textarea", group: "design" },
      { key: "ctaLabel", label: "Button label", type: "text", group: "design" },
      { key: "ctaHref", label: "Button link", type: "url", group: "settings" },
      { key: "bg", label: "Background", type: "color", group: "design" },
      { key: "textColor", label: "Text color", type: "color", group: "design" },
      { key: "align", label: "Align", type: "select", group: "design", options: ALIGN_OPTS },
    ],
    Render: HeroRender,
  },
  {
    type: "heading",
    label: "Heading",
    icon: Heading1,
    category: "Basics",
    description: "Section title",
    defaultProps: () => ({ text: "Section heading", align: "left" }),
    fields: [
      { key: "text", label: "Text", type: "text", group: "design" },
      { key: "align", label: "Align", type: "select", group: "design", options: ALIGN_OPTS },
    ],
    Render: HeadingRender,
  },
  {
    type: "paragraph",
    label: "Paragraph",
    icon: Pilcrow,
    category: "Basics",
    description: "Body text",
    defaultProps: () => ({
      text: "Write something compelling about your project here.",
      align: "left",
    }),
    fields: [
      { key: "text", label: "Text", type: "textarea", group: "design" },
      { key: "align", label: "Align", type: "select", group: "design", options: ALIGN_OPTS },
    ],
    Render: ParagraphRender,
  },
  {
    type: "button",
    label: "Button",
    icon: MousePointerClick,
    category: "Basics",
    description: "Call-to-action link",
    defaultProps: () => ({ label: "Click me", href: "#", variant: "solid", align: "left" }),
    fields: [
      { key: "label", label: "Label", type: "text", group: "design" },
      { key: "href", label: "Link", type: "url", group: "settings" },
      {
        key: "variant",
        label: "Style",
        type: "select",
        group: "design",
        options: [
          { label: "Solid", value: "solid" },
          { label: "Outline", value: "outline" },
        ],
      },
      { key: "align", label: "Align", type: "select", group: "design", options: ALIGN_OPTS },
    ],
    Render: ButtonRender,
  },
  {
    type: "divider",
    label: "Divider",
    icon: Minus,
    category: "Basics",
    description: "Horizontal rule",
    defaultProps: () => ({ spacing: "md" }),
    fields: [
      {
        key: "spacing",
        label: "Spacing",
        type: "select",
        group: "design",
        options: [
          { label: "Small", value: "sm" },
          { label: "Medium", value: "md" },
          { label: "Large", value: "lg" },
        ],
      },
    ],
    Render: DividerRender,
  },
  {
    type: "image",
    label: "Image",
    icon: ImageIcon,
    category: "Media",
    description: "Picture from a URL",
    defaultProps: () => ({
      src: "https://placehold.co/1200x600/0b1120/00ff66?text=Your+image",
      alt: "",
      rounded: "lg",
    }),
    fields: [
      { key: "src", label: "Image URL", type: "url", group: "settings" },
      { key: "alt", label: "Alt text", type: "text", group: "settings" },
      {
        key: "rounded",
        label: "Corners",
        type: "select",
        group: "design",
        options: [
          { label: "None", value: "none" },
          { label: "Medium", value: "md" },
          { label: "Large", value: "lg" },
          { label: "Full", value: "full" },
        ],
      },
    ],
    Render: ImageRender,
  },
  {
    type: "nft-gallery",
    label: "NFT Gallery",
    icon: Images,
    category: "Web3",
    description: "Grid of NFTs from a collection",
    defaultProps: () => ({ title: "My Collection", columns: "3" }),
    fields: [
      { key: "title", label: "Title", type: "text", group: "design" },
      {
        key: "columns",
        label: "Columns",
        type: "select",
        group: "design",
        options: [
          { label: "2", value: "2" },
          { label: "3", value: "3" },
          { label: "4", value: "4" },
        ],
      },
      { key: "collection", label: "Collection address", type: "text", group: "settings" },
    ],
    Render: NftGalleryRender,
  },
  {
    type: "wallet-connect",
    label: "Wallet Connect",
    icon: Wallet,
    category: "Web3",
    description: "Connect-wallet button",
    defaultProps: () => ({ label: "Connect Wallet" }),
    fields: [{ key: "label", label: "Label", type: "text", group: "design" }],
    Render: WalletConnectRender,
  },
];

const REGISTRY: Record<BlockType, BlockDef> = BLOCK_DEFS.reduce(
  (acc, def) => {
    acc[def.type] = def;
    return acc;
  },
  {} as Record<BlockType, BlockDef>,
);

export function getDef(type: BlockType): BlockDef {
  return REGISTRY[type];
}
