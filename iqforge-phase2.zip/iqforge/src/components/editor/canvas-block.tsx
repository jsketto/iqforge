"use client";

import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { motion } from "framer-motion";
import { GripVertical, Copy, Trash2 } from "lucide-react";
import type { Block } from "@/lib/editor/types";
import { getDef } from "@/lib/blocks/registry";
import { useEditor } from "@/lib/editor/store";
import { cn } from "@/lib/utils";

export function CanvasBlock({ block }: { block: Block }) {
  const { state, select, remove, duplicate } = useEditor();
  const selected = state.selectedId === block.id;
  const def = getDef(block.type);

  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: block.id, data: { kind: "canvas" } });

  // dnd-kit drives the transform; Framer (outer, in canvas) only handles
  // enter/exit so the two don't fight over `transform`.
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      onClick={(e) => {
        e.stopPropagation();
        select(block.id);
      }}
      className={cn(
        "group relative cursor-pointer outline-none ring-offset-0",
        isDragging && "z-10 opacity-60",
        selected
          ? "ring-2 ring-primary"
          : "ring-1 ring-transparent hover:ring-1 hover:ring-forge-muted/60",
      )}
    >
      {/* hover / selected toolbar */}
      <div
        className={cn(
          "absolute -top-3 right-2 z-20 flex items-center gap-1 rounded-md border border-border bg-popover px-1 py-0.5 shadow-md transition-opacity",
          selected ? "opacity-100" : "opacity-0 group-hover:opacity-100",
        )}
      >
        <button
          {...attributes}
          {...listeners}
          onClick={(e) => e.stopPropagation()}
          title="Drag to reorder"
          className="cursor-grab rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground active:cursor-grabbing"
        >
          <GripVertical size={14} />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            duplicate(block.id);
          }}
          title="Duplicate"
          className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <Copy size={14} />
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            remove(block.id);
          }}
          title="Delete"
          className="rounded p-1 text-muted-foreground hover:bg-accent hover:text-destructive"
        >
          <Trash2 size={14} />
        </button>
      </div>

      {/* type pill */}
      <span
        className={cn(
          "pointer-events-none absolute -top-3 left-2 z-20 rounded bg-primary px-1.5 py-0.5 font-mono text-[10px] font-semibold text-primary-foreground transition-opacity",
          selected ? "opacity-100" : "opacity-0 group-hover:opacity-100",
        )}
      >
        {def.label}
      </span>

      <def.Render props={block.props} device={state.device} />
    </div>
  );
}

// Motion wrapper used by the canvas list for enter/exit only.
export function CanvasBlockMotion({ block }: { block: Block }) {
  return (
    // No `layout` prop on purpose: dnd-kit owns the reorder transform/transition,
    // Framer only handles mount/unmount so the two don't fight over transform.
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ duration: 0.18, ease: "easeOut" }}
    >
      <CanvasBlock block={block} />
    </motion.div>
  );
}
