"use client";

import { useDroppable } from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { AnimatePresence, motion } from "framer-motion";
import { MousePointerSquareDashed } from "lucide-react";
import { useEditor } from "@/lib/editor/store";
import { getDef } from "@/lib/blocks/registry";
import { cn } from "@/lib/utils";
import { CanvasBlockMotion } from "./canvas-block";

export function Canvas() {
  const { state, select } = useEditor();
  const { blocks } = state.site;
  const { setNodeRef, isOver } = useDroppable({ id: "canvas" });

  const frameWidth = state.device === "mobile" ? "max-w-[390px]" : "max-w-3xl";

  return (
    <div
      className="flex flex-1 justify-center overflow-y-auto bg-grid p-6 [background-size:32px_32px]"
      onClick={() => select(null)}
    >
      <motion.div
        animate={{ width: state.device === "mobile" ? 390 : 768 }}
        transition={{ type: "spring", stiffness: 260, damping: 30 }}
        className={cn("w-full", frameWidth)}
      >
        <div
          ref={setNodeRef}
          className={cn(
            "min-h-[600px] overflow-hidden rounded-xl border bg-white shadow-2xl transition-colors",
            isOver ? "border-primary" : "border-border",
          )}
        >
          {state.preview ? (
            blocks.length === 0 ? (
              <div className="flex min-h-[600px] items-center justify-center text-sm text-neutral-400">
                Nothing to preview yet.
              </div>
            ) : (
              blocks.map((block) => {
                const def = getDef(block.type);
                return <def.Render key={block.id} props={block.props} device={state.device} />;
              })
            )
          ) : blocks.length === 0 ? (
            <div className="flex min-h-[600px] flex-col items-center justify-center gap-3 p-8 text-center">
              <motion.div
                animate={{ scale: isOver ? 1.08 : 1, opacity: isOver ? 1 : 0.7 }}
                className="flex flex-col items-center gap-3 text-neutral-400"
              >
                <MousePointerSquareDashed size={32} />
                <p className="font-medium text-neutral-500">
                  Drag a component here
                </p>
                <p className="text-sm text-neutral-400">
                  Pull anything from the left panel onto the page.
                </p>
              </motion.div>
            </div>
          ) : (
            <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
              <AnimatePresence initial={false}>
                {blocks.map((block) => (
                  <CanvasBlockMotion key={block.id} block={block} />
                ))}
              </AnimatePresence>
            </SortableContext>
          )}
        </div>
      </motion.div>
    </div>
  );
}
