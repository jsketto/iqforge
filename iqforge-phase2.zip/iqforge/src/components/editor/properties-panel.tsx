"use client";

import { SlidersHorizontal } from "lucide-react";
import { useEditor } from "@/lib/editor/store";
import { getDef, type FieldGroup } from "@/lib/blocks/registry";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";

function FieldList({ group }: { group: FieldGroup }) {
  const { selectedBlock } = useEditor();
  if (!selectedBlock) return null;
  const fields = getDef(selectedBlock.type).fields.filter((f) => f.group === group);

  if (fields.length === 0) {
    return (
      <p className="px-1 py-3 text-sm text-muted-foreground">
        No {group} options for this block yet.
      </p>
    );
  }

  // Phase 2 stop-point: this LOADS the selected block's fields + current values
  // (read-only) to prove selection → panel binding. Editable controls with
  // real-time canvas updates come next, after your feedback.
  return (
    <div className="space-y-3 py-3">
      {fields.map((f) => (
        <div key={f.key} className="px-1">
          <p className="text-xs font-medium text-muted-foreground">{f.label}</p>
          <p className="mt-1 truncate rounded-md border border-dashed border-border px-2 py-1.5 text-sm text-foreground/80">
            {String(selectedBlock.props[f.key] ?? "—")}
          </p>
        </div>
      ))}
      <p className="px-1 pt-1 text-xs text-muted-foreground/70">
        Editable controls land next phase.
      </p>
    </div>
  );
}

export function PropertiesPanel() {
  const { selectedBlock } = useEditor();

  return (
    <div className="flex h-full w-[320px] shrink-0 flex-col border-l border-border bg-card/40">
      <div className="px-4 py-4">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Properties
        </p>
        {selectedBlock && (
          <p className="mt-1 text-sm font-medium text-foreground">
            {getDef(selectedBlock.type).label}
          </p>
        )}
      </div>
      <Separator />

      {!selectedBlock ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 px-6 text-center text-muted-foreground">
          <SlidersHorizontal size={24} />
          <p className="text-sm">Select a block on the canvas to edit it.</p>
        </div>
      ) : (
        <ScrollArea className="flex-1 px-4 py-4">
          <Tabs defaultValue="design">
            <TabsList className="w-full">
              <TabsTrigger value="design" className="flex-1">
                Design
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex-1">
                Settings
              </TabsTrigger>
              <TabsTrigger value="advanced" className="flex-1">
                Advanced
              </TabsTrigger>
            </TabsList>
            <TabsContent value="design">
              <FieldList group="design" />
            </TabsContent>
            <TabsContent value="settings">
              <FieldList group="settings" />
            </TabsContent>
            <TabsContent value="advanced">
              <FieldList group="advanced" />
            </TabsContent>
          </Tabs>
        </ScrollArea>
      )}
    </div>
  );
}
