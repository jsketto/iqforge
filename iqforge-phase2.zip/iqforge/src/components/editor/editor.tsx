"use client";

import { useState } from "react";
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { sortableKeyboardCoordinates } from "@dnd-kit/sortable";
import { motion } from "framer-motion";
import { Monitor, Smartphone, Eye, Pencil } from "lucide-react";
import { EditorProvider, useEditor } from "@/lib/editor/store";
import { getDef } from "@/lib/blocks/registry";
import type { BlockType } from "@/lib/editor/types";
import { Library } from "./library";
import { Canvas } from "./canvas";
import { PropertiesPanel } from "./properties-panel";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

type ActiveDrag =
  | { kind: "library"; blockType: BlockType }
  | { kind: "canvas"; id: string }
  | null;

function DeviceButton({
  active,
  onClick,
  label,
  children,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      className={cn(
        "flex h-7 w-8 items-center justify-center rounded transition-colors",
        active
          ? "bg-secondary text-foreground"
          : "text-muted-foreground hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

function DragGhost({ active }: { active: NonNullable<ActiveDrag> }) {
  const def =
    active.kind === "library" ? getDef(active.blockType) : null;
  const label = def?.label ?? "Block";
  const Icon = def?.icon;

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0.9 }}
      animate={{ scale: 1, opacity: 1 }}
      className="pointer-events-none flex items-center gap-2 rounded-md border border-primary/60 bg-popover px-3 py-2 text-sm font-medium text-foreground shadow-forge"
    >
      {Icon ? <Icon size={15} className="text-forge-dim" /> : null}
      {label}
    </motion.div>
  );
}

function EditorInner() {
  const { state, setName, addBlock, move, setDevice, setPreview } = useEditor();
  const [active, setActive] = useState<ActiveDrag>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  function onDragStart(e: DragStartEvent) {
    const data = e.active.data.current as
      | { kind?: string; blockType?: BlockType }
      | undefined;
    if (data?.kind === "library" && data.blockType) {
      setActive({ kind: "library", blockType: data.blockType });
    } else {
      setActive({ kind: "canvas", id: String(e.active.id) });
    }
  }

  function onDragEnd(e: DragEndEvent) {
    setActive(null);
    const { active: a, over } = e;
    if (!over) return;

    const data = a.data.current as
      | { kind?: string; blockType?: BlockType }
      | undefined;
    const blocks = state.site.blocks;
    const overId = String(over.id);

    if (data?.kind === "library" && data.blockType) {
      const idx =
        overId === "canvas"
          ? blocks.length
          : blocks.findIndex((b) => b.id === overId);
      addBlock(data.blockType, idx === -1 ? blocks.length : idx);
      return;
    }

    // reorder within canvas
    const from = blocks.findIndex((b) => b.id === String(a.id));
    const to =
      overId === "canvas"
        ? blocks.length - 1
        : blocks.findIndex((b) => b.id === overId);
    if (from !== -1 && to !== -1) move(from, to);
  }

  return (
    <div className="flex h-full flex-col">
      {/* Editor toolbar */}
      <div className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-card/40 px-4">
        <Input
          value={state.site.name}
          onChange={(e) => setName(e.target.value)}
          className="h-8 w-56 border-transparent bg-transparent px-2 font-display text-base hover:border-border focus-visible:border-border"
          aria-label="Site name"
        />

        <div className="flex items-center gap-0.5 rounded-md border border-border p-0.5">
          <DeviceButton
            active={state.device === "desktop"}
            onClick={() => setDevice("desktop")}
            label="Desktop"
          >
            <Monitor size={15} />
          </DeviceButton>
          <DeviceButton
            active={state.device === "mobile"}
            onClick={() => setDevice("mobile")}
            label="Mobile"
          >
            <Smartphone size={15} />
          </DeviceButton>
        </div>

        <Button
          variant={state.preview ? "default" : "outline"}
          size="sm"
          className="font-mono"
          onClick={() => setPreview(!state.preview)}
        >
          {state.preview ? (
            <>
              <Pencil size={14} /> Edit
            </>
          ) : (
            <>
              <Eye size={14} /> Preview
            </>
          )}
        </Button>
      </div>

      {/* Body: Library · Canvas · Properties */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={onDragStart}
        onDragEnd={onDragEnd}
        onDragCancel={() => setActive(null)}
      >
        <div className="flex min-h-0 flex-1">
          {!state.preview && <Library />}
          <Canvas />
          {!state.preview && <PropertiesPanel />}
        </div>

        <DragOverlay dropAnimation={null}>
          {active ? <DragGhost active={active} /> : null}
        </DragOverlay>
      </DndContext>
    </div>
  );
}

export function Editor() {
  return (
    <EditorProvider>
      <EditorInner />
    </EditorProvider>
  );
}
