"use client";

import { useMemo, useState } from "react";
import { useDraggable } from "@dnd-kit/core";
import { Search } from "lucide-react";
import {
  BLOCK_DEFS,
  CATEGORY_ORDER,
  type BlockDef,
  type LibraryCategory,
} from "@/lib/blocks/registry";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";

function LibraryCard({ def }: { def: BlockDef }) {
  // id is prefixed so onDragEnd can distinguish a new-block drag from a reorder.
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `lib:${def.type}`,
    data: { kind: "library", blockType: def.type },
  });
  const Icon = def.icon;

  return (
    <button
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={cn(
        "flex w-full cursor-grab touch-none items-center gap-3 rounded-md border border-border bg-card px-3 py-2 text-left text-sm text-foreground/90 transition-colors hover:border-forge-muted hover:bg-accent active:cursor-grabbing",
        isDragging && "opacity-40",
      )}
    >
      <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-secondary text-forge-dim">
        <Icon size={16} />
      </span>
      <span className="min-w-0">
        <span className="block font-medium leading-tight">{def.label}</span>
        <span className="block truncate text-xs text-muted-foreground">
          {def.description}
        </span>
      </span>
    </button>
  );
}

export function Library() {
  const [query, setQuery] = useState("");

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    const map = new Map<LibraryCategory, BlockDef[]>();
    for (const def of BLOCK_DEFS) {
      if (q && !def.label.toLowerCase().includes(q) && !def.description.toLowerCase().includes(q)) {
        continue;
      }
      const list = map.get(def.category) ?? [];
      list.push(def);
      map.set(def.category, list);
    }
    return map;
  }, [query]);

  return (
    <div className="flex h-full w-[280px] shrink-0 flex-col border-r border-border bg-card/40">
      <div className="px-4 py-4">
        <p className="mb-3 font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground">
          Components
        </p>
        <div className="relative">
          <Search
            size={14}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search components"
            className="pl-9"
          />
        </div>
      </div>
      <Separator />
      <ScrollArea className="flex-1 px-4 py-4">
        <div className="space-y-5">
          {CATEGORY_ORDER.map((category) => {
            const defs = grouped.get(category);
            if (!defs || defs.length === 0) return null;
            return (
              <div key={category}>
                <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground/80">
                  {category}
                </p>
                <div className="space-y-2">
                  {defs.map((def) => (
                    <LibraryCard key={def.type} def={def} />
                  ))}
                </div>
              </div>
            );
          })}
          {grouped.size === 0 && (
            <p className="px-1 text-sm text-muted-foreground">
              No components match “{query}”.
            </p>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
